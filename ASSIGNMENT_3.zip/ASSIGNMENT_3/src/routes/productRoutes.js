const express = require('express');
const controller = require('../controllers/productController');
const {
  validateObjectId,
  validateCreate,
  validateUpdate,
  validateStock,
  validateQuery
} = require('../middleware/validation');

const router = express.Router();

router.post('/', validateCreate, controller.createProduct);
router.get('/', validateQuery, controller.getProducts);
router.get('/low-stock', controller.getLowStock);
router.get('/summary', controller.getCategorySummary);
router.get('/:id', validateObjectId, controller.getProductById);
router.put('/:id', validateObjectId, validateUpdate, controller.updateProduct);
router.delete('/:id', validateObjectId, controller.deleteProduct);
router.patch('/:id/stock', validateObjectId, validateStock, controller.adjustStock);

module.exports = router;
