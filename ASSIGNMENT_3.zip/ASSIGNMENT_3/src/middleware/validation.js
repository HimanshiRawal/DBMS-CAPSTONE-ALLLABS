const mongoose = require('mongoose');

const productFields = ['name', 'sku', 'category', 'price', 'quantity', 'reorderLevel', 'supplier'];

const createError = (message, statusCode = 400) => {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
};

const validateObjectId = (req, res, next) => {
  if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
    return next(createError('Invalid product ID'));
  }
  next();
};

const validateCreate = (req, res, next) => {
  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    return next(createError('Request body must be a JSON object'));
  }

  const unexpected = Object.keys(req.body).filter((field) => !productFields.includes(field));
  if (unexpected.length) {
    return next(createError(`Unexpected field(s): ${unexpected.join(', ')}`));
  }

  const missing = productFields.filter((field) => req.body[field] === undefined);
  if (missing.length) {
    return next(createError(`Missing required field(s): ${missing.join(', ')}`));
  }
  next();
};

const validateUpdate = (req, res, next) => {
  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    return next(createError('Request body must be a JSON object'));
  }

  const keys = Object.keys(req.body);
  const unexpected = keys.filter((field) => !productFields.includes(field));
  if (unexpected.length) {
    return next(createError(`Unexpected field(s): ${unexpected.join(', ')}`));
  }
  if (!keys.length) {
    return next(createError('At least one product field is required'));
  }
  next();
};

const validateStock = (req, res, next) => {
  const change = req.body && req.body.change;
  if (
    !req.body ||
    typeof req.body !== 'object' ||
    Array.isArray(req.body) ||
    typeof change !== 'number' ||
    !Number.isFinite(change)
  ) {
    return next(createError('change must be a numeric value'));
  }
  if (!Number.isInteger(change)) {
    return next(createError('change must be a whole number'));
  }
  next();
};

const validateQuery = (req, res, next) => {
  const { page, limit, minPrice, maxPrice, sortBy, order } = req.query;

  if (page !== undefined && (!/^\d+$/.test(page) || Number(page) < 1)) {
    return next(createError('page must be a positive integer'));
  }
  if (limit !== undefined && (!/^\d+$/.test(limit) || Number(limit) < 1 || Number(limit) > 100)) {
    return next(createError('limit must be a positive integer no greater than 100'));
  }

  for (const [name, value] of [['minPrice', minPrice], ['maxPrice', maxPrice]]) {
    if (value !== undefined && (value.trim() === '' || !Number.isFinite(Number(value)) || Number(value) < 0)) {
      return next(createError(`${name} must be a non-negative number`));
    }
  }
  if (minPrice !== undefined && maxPrice !== undefined && Number(minPrice) > Number(maxPrice)) {
    return next(createError('minPrice cannot be greater than maxPrice'));
  }

  if (sortBy !== undefined) {
    const allowedSortFields = ['name', 'sku', 'category', 'price', 'quantity', 'reorderLevel', 'supplier', 'createdAt', 'updatedAt'];
    if (!allowedSortFields.includes(sortBy)) {
      return next(createError(`Invalid sortBy value. Allowed: ${allowedSortFields.join(', ')}`));
    }
  }
  if (order !== undefined && !['asc', 'desc'].includes(order.toLowerCase())) {
    return next(createError('order must be "asc" or "desc"'));
  }
  next();
};

module.exports = {
  validateObjectId,
  validateCreate,
  validateUpdate,
  validateStock,
  validateQuery
};
